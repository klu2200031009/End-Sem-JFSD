package com.project.ProjectHelpingHands.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;



@Controller
@RequestMapping("/donation")
public class DonationDriveController {

    @Autowired
    private DonationDriveDAOImpl service;

    

    @GetMapping("/add")
    public String showAddDonationForm(Model model) {
        model.addAttribute("donationDrive", new DonationDrive());
        return "addDonation";
    }

    @PostMapping("/add")
    public String addDonationDrive(@ModelAttribute DonationDrive donationDrive, 
                                   @RequestParam("imageFile") MultipartFile imageFile)  {
        service.saveDonationDrive(donationDrive, imageFile);
        return "redirect:/donation/list";
    }

    @GetMapping("/list")
    public String listDonationDrives(Model model) {
        List<DonationDrive> donationDrives = service.getAllDrives();
        
        // Debug: Print out the list of drives to ensure data is fetched
        for (DonationDrive drive : donationDrives) {
            System.out.println(drive.getEventName());  // Debugging output
        }

        model.addAttribute("donationDrives", donationDrives);
        return "listDonations";
    }
    
    @GetMapping("/viewDrives")
    public String viewdrives(Model model) {
List<DonationDrive> donationDrives = service.getAllDrives();
        
       
        model.addAttribute("donationDrives", donationDrives);
        return "viewDonationDrive";
    }


    // Edit Donation Drive
    @GetMapping("/edit/{id}")
    public String showEditDonationForm(@PathVariable("id") Long id, Model model) {
        DonationDrive donationDrive = service.getDriveById(id);
        model.addAttribute("donationDrive", donationDrive);
        return "editDonation";  // This is the page where you will edit the donation drive
    }

    @PostMapping("/edit/{id}")
    public String editDonationDrive(@PathVariable("id") Long id, 
                                    @ModelAttribute DonationDrive donationDrive,
                                    @RequestParam("imageFile") MultipartFile imageFile) {
        service.updateDonationDrive(id, donationDrive, imageFile);
        return "redirect:/donation/viewDrives";
    }

    // Delete Donation Drive
    @GetMapping("/delete/{id}")
    public String deleteDonationDrive(@PathVariable("id") Long id) {
        service.deleteDonationDrive(id);
        return "redirect:/donation/viewDrives";
    }
    @Controller
    public class FundraiseController {

        @PostMapping("/fundraise")
        public String handleFundraise(@RequestParam("amount") double amount, @RequestParam("description") String description, Model model) {
            // Process the donation, e.g., save to database, etc.

            // If successful:
            model.addAttribute("message", "Thank you for your generous donation!");

            // If there was an issue:
            // model.addAttribute("message", "There was an issue processing your donation.");

            return "fundraise";  // Return to the same JSP page
        }
    }
    @Controller
    public class FoodCampaignController {

        @GetMapping("/startCampaign")
        public String getFoodCampaignStats(Model model) {
            // Fetch the number of countries that started food campaigns (example: from database)
            int noOfCountries = fetchNoOfCountries(); // Replace with actual logic

            // Add the number to the model
            model.addAttribute("noOfCountries", noOfCountries);

            // Return the JSP page name
            return "startCampaign"; // Ensure the JSP file name matches this
        }

        private int fetchNoOfCountries() {
            // Replace this with actual logic to fetch the count from the database
            return 12; // Example static value
        }
    }

   
    
}
