package com.project.ProjectHelpingHands;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;

@Controller
public class DonarController {
	
	 @Autowired
	private DonarDAOImpl dd;
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	@GetMapping("/donation")
	public String admin() {
		return "donation";
	}
	@GetMapping("/donationsuccessful")
	public String invalid() {
		return "donationsuccessful";
	}
	
	 @PostMapping("/loginPage")
	    public String login(@RequestParam("email") String email, 
	                        @RequestParam("password") String password, 
	                        Model model, HttpSession session) {

	        Donar donar = dd.authenticateUser(email, password);

	        if (donar != null) {
	        	 session.setAttribute("user", donar);
		            model.addAttribute("message", "Login successful!");
	        	  if (donar.isAdmin()) {
	                  return "adminhome"; // Redirect to admin home page if the user is an admin
	              } else {
	                  return "donarhome"; // Redirect to donor home page if the user is not an admin
	              }
	           
	           
	        } else {
	            model.addAttribute("error", "Invalid email or password");
	            return "login"; // Redirect back to login page with error message
	        }
	    }
	 
	 
	 
	 @GetMapping("/logout")
	    public String logout(HttpSession session) {
	        // Invalidate the session
	        session.invalidate();
	        
	        // Redirect to the home page (adjust path as necessary)
	        return "redirect:/"; // Redirect to the home page after logout
	    }
	 
	 
	@GetMapping("/aboutus")
	public String aboutus() {
		return "aboutus";
	}
	@GetMapping("/listDonations")
	public String list() {
		return "listDonations";
	}
	@GetMapping("/registration")
	public String registration() {
		return "registration";
	}
	 @PostMapping("/addDonar")
	 public String addDonar(@ModelAttribute Donar d, Model model) {
		 model.addAttribute("Donar", d);
		 System.out.println(dd.insertDonar(d));
		 return "Done";
	 }
	 @GetMapping("/fundraise")
		public String donarhome() {
			return "fundraise";
		}
	 @PostMapping("/submitFundraiser")
	 public String submitFundraiser() {
	    
	     return "success";
	 }
	  @GetMapping("/wastage")
	    public String showWastagePage() {
	        return "wastage"; // Maps to a template named "wastage.html" or "wastage.jsp"
	    }
	  @GetMapping("/globe")
	    public String show() {
	        return "globe"; // Maps to a template named "wastage.html" or "wastage.jsp"
	    }
	  @GetMapping("/orders")
	    public String show2() {
	        return "orders"; // Maps to a template named "wastage.html" or "wastage.jsp"
	    }
	  @GetMapping("/viewallproducts")
	    public String show3() {
	        return "viewallproducts"; // Maps to a template named "wastage.html" or "wastage.jsp"
	    }
	  
	 

	  @GetMapping("/viewUsers")
	    public String viewUsers(Model model) {
		  List<Donar> users = dd.getAllNonAdminUsers();
		 
		    model.addAttribute("users", users);
	        return "viewUsers";
	    }
	  

}
